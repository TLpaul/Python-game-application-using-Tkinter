#terry Paul hd9796 2/1/24 InclassAssignment
import tkinter as tk
from tkinter import simpledialog, messagebox
import random

def game_one():
    #inltizing variables
    playerscore = 0
    #gives a random  int for  play er to guess
    answer = random.randint(1, 4)

#menu to run the game  while usere guesses correctly or exits the game  if they close app
    while True:
        #ask for input from user for number guess
        guess = simpledialog.askinteger("Guess the Number", "Guess a number between 1 and 4 enter")
        if guess is None: #message to show if game exited
            messagebox.showinfo("Game Ended", "You ended the game.")
            break
        if guess == answer:
            playerscore += 1 #incrmenets scor eif correct gase
            messagebox.showinfo("Correct!", f"You guessed it right! Your score: {playerscore}")
            answer = random.randint(1, 4)     #gives a random  int for  play er to guess

        else: #if wrong guess exit app
            messagebox.showinfo("Game Over", f"Wrong guess! The correct number was {answer}. Final score: {playerscore}")
            break

def game_two():
    score = 0 #initlzie score 
    while True:
        answer = random.randint(1, 2)     #gives a random  int for  play er to guess

        guess = simpledialog.askinteger("1's or 2's", "Guess 1 or 2 (Enter 3 to exit):")

        if guess == 3:
            messagebox.showinfo("Game Over", f"Game ended. Final score: {score}")
            break
        elif guess == answer:
            score += 1 #incrment score 
            messagebox.showinfo("Correct!", f"You guessed it right! Your score: {score}")
        else:
            messagebox.showinfo("Wrong!", "Wrong guess! Try again.")

#inltiize the window foe app
root = tk.Tk()
root.title("Game Launcher") #gives window a title

#create a button for the frist game funciton
button1 = tk.Button(root, text="Number Guess", command=game_one)
button1.pack(pady=10) #gives the padding for btton
#create a button for the second game funciton
button2 = tk.Button(root, text="1's or 2's", command=game_two)
button2.pack(pady=10)

#loops the game window to keep game running 
root.mainloop()
